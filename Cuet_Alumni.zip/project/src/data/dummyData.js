export const dummyPosts = [
  {
    id: 1,
    content: "Just completed my final year project on AI! Looking forward to sharing my experience with juniors.",
    author: "John Doe",
    timestamp: "2024-03-10T10:00:00Z",
    likes: 15,
    comments: [
      {
        id: 1,
        author: "Jane Smith",
        content: "That's amazing! Would love to learn from your experience.",
        timestamp: "2024-03-10T10:30:00Z"
      }
    ]
  },
  {
    id: 2,
    content: "Organizing a workshop on Web Development next week. All current students are welcome!",
    author: "Sarah Wilson",
    timestamp: "2024-03-09T15:00:00Z",
    likes: 24,
    comments: []
  }
];

export const dummyChats = [
  {
    id: 1,
    user: "Jane Smith",
    lastMessage: "Hey, how are you?",
    timestamp: "2024-03-10T10:00:00Z",
    messages: [
      {
        id: 1,
        sender: "Jane Smith",
        content: "Hey, how are you?",
        timestamp: "2024-03-10T10:00:00Z"
      },
      {
        id: 2,
        sender: "Current User",
        content: "I'm good! How about you?",
        timestamp: "2024-03-10T10:05:00Z"
      }
    ]
  },
  {
    id: 2,
    user: "Bob Johnson",
    lastMessage: "Thanks for the help!",
    timestamp: "2024-03-09T14:30:00Z",
    messages: [
      {
        id: 1,
        sender: "Bob Johnson",
        content: "Could you help me with the project?",
        timestamp: "2024-03-09T14:00:00Z"
      },
      {
        id: 2,
        sender: "Current User",
        content: "Sure, what do you need?",
        timestamp: "2024-03-09T14:15:00Z"
      },
      {
        id: 3,
        sender: "Bob Johnson",
        content: "Thanks for the help!",
        timestamp: "2024-03-09T14:30:00Z"
      }
    ]
  }
];