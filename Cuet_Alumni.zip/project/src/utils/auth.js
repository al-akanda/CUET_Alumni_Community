// Simulated authentication state
let isAuthenticated = false;

export const login = (email, password) => {
  // Simulate login
  if (email && password) {
    isAuthenticated = true;
    return true;
  }
  return false;
};

export const logout = () => {
  isAuthenticated = false;
};

export const checkAuth = () => {
  return isAuthenticated;
};