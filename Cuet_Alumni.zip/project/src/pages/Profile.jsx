import { useState } from 'react';
import { Link } from 'react-router-dom';

function Profile() {
  const [userProfile] = useState({
    name: 'John Doe',
    type: 'Alumni',
    graduationYear: '2020',
    department: 'Computer Science & Engineering',
    currentPosition: 'Software Engineer',
    company: 'Tech Corp',
    bio: 'Passionate about technology and innovation',
    email: 'john.doe@example.com',
  });

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">{userProfile.name}</h2>
          <Link
            to="/edit-profile"
            className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
          >
            Edit Profile
          </Link>
        </div>

        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-semibold">Basic Information</h3>
            <div className="grid grid-cols-2 gap-4 mt-2">
              <div>
                <p className="text-gray-600">Type</p>
                <p>{userProfile.type}</p>
              </div>
              <div>
                <p className="text-gray-600">Graduation Year</p>
                <p>{userProfile.graduationYear}</p>
              </div>
              <div>
                <p className="text-gray-600">Department</p>
                <p>{userProfile.department}</p>
              </div>
              <div>
                <p className="text-gray-600">Email</p>
                <p>{userProfile.email}</p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold">Professional Information</h3>
            <div className="grid grid-cols-2 gap-4 mt-2">
              <div>
                <p className="text-gray-600">Current Position</p>
                <p>{userProfile.currentPosition}</p>
              </div>
              <div>
                <p className="text-gray-600">Company</p>
                <p>{userProfile.company}</p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold">Bio</h3>
            <p className="mt-2">{userProfile.bio}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Profile;