import { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';

function Post({ post }) {
  const [likes, setLikes] = useState(post.likes);
  const [showComments, setShowComments] = useState(false);

  const handleLike = () => {
    setLikes(prev => prev + 1);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-4">
        <div className="font-semibold">{post.author}</div>
        <div className="text-gray-500 text-sm ml-2">
          {formatDistanceToNow(new Date(post.timestamp), { addSuffix: true })}
        </div>
      </div>
      <p className="mb-4">{post.content}</p>
      <div className="flex items-center space-x-4">
        <button 
          onClick={handleLike}
          className="text-gray-500 hover:text-blue-600"
        >
          Like ({likes})
        </button>
        <button 
          onClick={() => setShowComments(!showComments)}
          className="text-gray-500 hover:text-blue-600"
        >
          Comments ({post.comments.length})
        </button>
        <button className="text-gray-500 hover:text-blue-600">
          Share
        </button>
      </div>
      
      {showComments && (
        <div className="mt-4 space-y-3">
          {post.comments.map(comment => (
            <div key={comment.id} className="bg-gray-50 p-3 rounded-md">
              <div className="flex items-center mb-1">
                <span className="font-medium">{comment.author}</span>
                <span className="text-gray-500 text-xs ml-2">
                  {formatDistanceToNow(new Date(comment.timestamp), { addSuffix: true })}
                </span>
              </div>
              <p className="text-gray-700">{comment.content}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Post;