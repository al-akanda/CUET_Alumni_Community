function ChatList({ chats, selectedChat, onSelectChat }) {
  return (
    <div className="w-1/3 border-r">
      <div className="p-4 border-b">
        <h2 className="text-xl font-semibold">Messages</h2>
      </div>
      <div className="overflow-y-auto h-[calc(600px-4rem)]">
        {chats.map((chat) => (
          <div
            key={chat.id}
            onClick={() => onSelectChat(chat)}
            className={`p-4 cursor-pointer hover:bg-gray-50 ${
              selectedChat?.id === chat.id ? 'bg-gray-50' : ''
            }`}
          >
            <div className="font-semibold">{chat.user}</div>
            <div className="text-sm text-gray-500">{chat.lastMessage}</div>
            <div className="text-xs text-gray-400">
              {new Date(chat.timestamp).toLocaleDateString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ChatList;