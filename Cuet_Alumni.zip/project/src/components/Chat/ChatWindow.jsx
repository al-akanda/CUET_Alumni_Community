function ChatWindow({ selectedChat, message, setMessage, handleSendMessage }) {
  if (!selectedChat) {
    return (
      <div className="w-2/3 flex items-center justify-center text-gray-500">
        Select a chat to start messaging
      </div>
    );
  }

  return (
    <div className="w-2/3 flex flex-col">
      <div className="p-4 border-b">
        <h3 className="text-lg font-semibold">{selectedChat.user}</h3>
      </div>
      <div className="flex-1 overflow-y-auto p-4">
        {selectedChat.messages.map((msg) => (
          <div
            key={msg.id}
            className={`mb-4 ${
              msg.sender === selectedChat.user ? 'text-left' : 'text-right'
            }`}
          >
            <div
              className={`inline-block p-3 rounded-lg ${
                msg.sender === selectedChat.user
                  ? 'bg-gray-100'
                  : 'bg-blue-600 text-white'
              }`}
            >
              {msg.content}
            </div>
            <div className="text-xs text-gray-400 mt-1">
              {new Date(msg.timestamp).toLocaleTimeString()}
            </div>
          </div>
        ))}
      </div>
      <div className="p-4 border-t">
        <form onSubmit={handleSendMessage} className="flex space-x-2">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="flex-1 px-3 py-2 border rounded-md"
            placeholder="Type a message..."
          />
          <button
            type="submit"
            className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  );
}

export default ChatWindow;